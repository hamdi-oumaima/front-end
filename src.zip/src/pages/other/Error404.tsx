// import { Link } from 'react-router-dom';

// components

import { Fragment } from 'react';

import AboutUs from '../../components/About-us/AboutUs';
import HeroSection from '../../components/Hero-Section/HeroSection';
import Features from '../../components/Feature-section/Features';
import Company from '../../components/Company-section/Company';
import Courses from '../../components/Courses-section/Courses';
import ChooseUs from '../../components/Choose-us/ChooseUs';
import Newsletter from '../../components/Newsletter/Newsletter';


const Error404 = () => {
    return (

        <>
     

<Fragment>

   
    <HeroSection />
    <Features/>
    <AboutUs />
    <Company/>
   <Courses/>
   <ChooseUs/>
   <Newsletter/>
   

   

</Fragment>

        
        </>
        

    );
};

export default Error404;
