export type TabContent = {
    id: number;
    title: string;
    text: string;
};
