



import { Link } from 'react-router-dom';
import { Badge, Card, Col, OverlayTrigger, ProgressBar, Row, Tooltip } from 'react-bootstrap';
import classNames from 'classnames';
import { ProjectsList } from '../../pages/apps/Projects/types';

 

 
const SingleCour = () =>{

 
    const projects = [
        {
            id: 1,
            title: 'New Admin Design',
            category: 'WEB DESIGN',
            state: 'Completed',
            shortDesc:
                'If several languages coalesce the grammar is more simple and regular than that of the individual languages...',
            question: 56,
            comment: 452,
           
            progress: 80,
            variant: 'success',
        },
        {
            id: 2,
            title: 'App Design and Develop',
            category: 'ANDROID',
            state: 'Completed',
            shortDesc: 'New common language will be more simple and regular than the existing European languages...',
            question: 77,
            comment: 875,
            
            progress: 45,
            variant: 'primary',
        },
        {
            id: 3,
            title: 'Landing page Design',
            category: 'WEB DESIGN',
            state: 'Completed',
            shortDesc:
                'It will be as simple as occidental in fact it will be to an english person it will seem like simplified English...',
            question: 87,
            comment: 125,
            
            progress: 68,
            variant: 'pink',
        },
        {
            id: 4,
            title: 'App Design and Develop',
            category: 'ANDROID',
            state: 'Completed',
            shortDesc:
                'Everyone realizes why a new common language would be desirable one could refuse to pay expensive translators...',
            question: 77,
            comment: 875,
            
            progress: 45,
            variant: 'purple',
        },
        {
            id: 5,
            title: 'Landing page Design',
            category: 'WEB DESIGN',
            state: 'Completed',
            shortDesc: 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium deleniti...',
            question: 87,
            comment: 125,
            
            progress: 68,
            variant: 'danger',
        },
        {
            id: 6,
            title: 'New Admin Design',
            category: 'WEB DESIGN',
            state: 'Completed',
            shortDesc:
                'Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary....',
            question: 56,
            comment: 452,
             
            progress: 80,
            variant: 'warning',
        },
    ];
    
    const SingleProject = ( ) => {
        return (
            <Row>
                {(projects || []).map((project, index) => {
                    return (
                        <Col xl={4} key={index.toString()}>
                            <Card>
                                <Card.Body className="project-box">
                                    <Badge bg={project.variant} className="float-end">
                                        {project.state}
                                    </Badge>
                                    <h4 className="mt-0">
                                        <Link to="#" className="text-dark">
                                            {project.title}
                                        </Link>
                                    </h4>
                                    <p className={classNames('text-' + project.variant, 'text-uppercase', 'font-13')}>
                                        {project.category}
                                    </p>
                                    <p className="text-muted font-13">
                                        {project.shortDesc}
                                        <Link to="#" className="text-primary">
                                            View more
                                        </Link>
                                    </p>
    
                                    <ul className="list-inline">
                                        <li className="list-inline-item me-4">
                                            <h4 className="mb-0">{project.question}</h4>
                                            <p className="text-muted">Questions</p>
                                        </li>
                                        <li className="list-inline-item">
                                            <h4 className="mb-0">{project.comment}</h4>
                                            <p className="text-muted">Comments</p>
                                        </li>
                                    </ul>
    
                                
    
                                    <h5 className="mb-2 fw-semibold">
                                        Progress
                                        <span className={classNames('float-end', 'text-' + project.variant)}>
                                            {project.progress}%
                                        </span>
                                    </h5>
                                    <ProgressBar
                                        className={classNames('progress-bar-alt-' + project.variant, 'progress-sm')}
                                    >
                                        <ProgressBar
                                            variant={project.variant}
                                            now={project.progress}
                                            className="progress-animated"
                                        />
                                    </ProgressBar>
                                </Card.Body>
                            </Card>
                        </Col>
                    );
                })}
 
            </Row>
        );
    };

    
 
    return (
        <>
  <Row>

    <SingleProject ></SingleProject>

</Row>
    
   </>
    );
   
    };
    
    
    export default SingleCour;

   




