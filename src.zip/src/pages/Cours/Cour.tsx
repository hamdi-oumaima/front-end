
import { Col, Row } from 'react-bootstrap';
import { usePageTitle } from '../../hooks';
import "../../assets/images/Html-Css.jpg";
import "./Cour.css";
import SingleCour from './SingleCour';

 
const Cour = () =>{


    
     
     usePageTitle({
         title: '',
         breadCrumbItems: [
             {
                 path: '/Cour',
                 label: 'Cour',
                 active: true,
             },
         ],
     });

    return (
        <>


  

    <div className="main-bar">
        <div className="container">
            <div className="row">
                    <div className="four columns icon icon1">
                        <p>20,000 online courses <br/>
                        Learn new skills</p>
                    </div>
                    <div className="four columns icon icon2">
                        <p>Expert Instructors<br/>
                        Learn with different teach styles</p>
                    </div>
                    <div className="four columns icon icon3">
                        <p>Lifetime access <br/> learn at your own pace</p>
                       
                    </div>
            </div>
        </div>

    </div>
 

<SingleCour></SingleCour>
 
   </>
    );
   
    };
    
    
    export default Cour;

   



