import { Button, Card, Col } from 'react-bootstrap';


// images
import cardImg1 from '../../../assets/images/gallery/2.jpg';
import cardImg2 from '../../../assets/images/gallery/3.jpg';
import cardImg3 from '../../../assets/images/gallery/4.jpg';

const CardCour = () => {
    return (
        <>
  
  

  
            <Col xs={5} >
                <Card className='cardCour'>
                <Card.Img src={cardImg1} />
                <h5 className='titreCard'>9,99 $US <br/> 80% de réduction </h5>
                <p className='clockpara'><i className=' fas fa-clock'></i>Il vous reste 4 jours pour bénéficier de ce prix !</p>
                       
                <Button variant="secondary" className="width-xl waves-effect waves-light">
                   Ajouter au panier
                </Button><br/>
                <Button variant="secondary" className="width-xl waves-effect waves-light">
                   Acheter dés maintenant
                </Button>
                       
                    {/* <Card.Img src={cardImg2} /> */}
               <Card.Body>

                <Card.Text>
                         Garantie satisfait ou remboursè de 30 jours
                        <h4>Ce cours comprend</h4>
                        <p> <i className="  fas fa-video"></i>  Vidéo à la demande de 3 heures
                        <br/><i className=" dripicons-article"></i>  1 article
                        <br/><i className=" fas fa-file-download"></i>  1 ressource téléchargeable
                        <br/><i className=" fas fa-mobile-alt"></i>  Accès sur mobiles et TV
                        <br/><i className=' far fa-check-circle'></i>    Accès illimité
                        <br/><i className=' fas fa-trophy' ></i>  Certificat de fin de formation      
                        </p>
                </Card.Text>
                <Card.Text>
                    <h3>Formez-vous 5 personnes ou plus?</h3>
                        <p >Offrez aux membres de votre équipe un accès à plus de 25 000 
                        des meilleurs cours Udemy, à tout moment, où qu'ils soient.</p>
                </Card.Text>
             

            
 
             
               
                
                </Card.Body>

                <Button variant="secondary" className="width-xl waves-effect waves-light">
                   Ajouter au panier
                </Button>
             
                </Card>
            </Col>

        </>
    );
};

export default CardCour;
