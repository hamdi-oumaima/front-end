
import { Card, Col, Row } from 'react-bootstrap';
import { usePageTitle } from '../../../hooks';
import classNames from 'classnames';
import { Link } from 'react-router-dom';
import { postsCour } from './data';
 import "../Cour.css"
 
const AvisCour = () =>{


    
     
     usePageTitle({
         title: '',
         breadCrumbItems: [
             {
                 path: '/AvisCour',
                 label: 'AvisCour',
                 active: true,
             },
         ],
     });
 
 return (
        <Card>
            <Card.Body>
            <Row>
                {(postsCour || []).map((post, index) => {
                    return (
                        <Col xl={6} key={index.toString()}>
                    
                        <div
                            className={classNames('d-flex', 'align-items-top', index === 0 ? 'mb-2' : 'mb-3')}
                            key={index.toString()}
                        >
                            <img
                                src={post.avatar}
                                alt="avatar"
                                className="flex-shrink-0 comment-avatar avatar-sm rounded me-2"
                            />
                            <div className="flex-grow-1">
                                <h5 className="mt-0">
                                    <Link to="#" className="text-dark">
                                        {post.name}
                                        <small className="ms-1 text-muted">{post.time}</small>
                                    </Link>
                                     <br/><i className="fas fa-star starsColor"></i>
                                    <i className="fas fa-star starsColor"></i> 
                                    <i className="fas fa-star starsColor"></i> 
                                    <i className="fas fa-star-half-alt starsColor"></i> 
                                    <i className="far fa-star starsColor"></i>  
                                </h5>
                                
                                <p>{post.content.message}</p>
                                <div>
                                    {(post.content.media || []).map((item, index) => {
                                        return (
                                            <Link to="#" key={index.toString()}>
                                                <img src={item} alt="media" className="avatar-md rounded me-1" />
                                            </Link>
                                        );
                                    })}
                                </div>
                                <div
                                    className={classNames('comment-footer', {
                                        'mb-3': post.comments && post.comments!.length > 0,
                                        'pt-2': post.content.media,
                                    })}
                                >
                                    <Link to="#">
                                        <i className="far fa-thumbs-up" />
                                    </Link>
                                    <Link to="#">
                                        <i className="far fa-thumbs-down" />
                                    </Link>
                                    <Link to="#">Reply</Link>
                                </div>
                        
                            </div>
                        </div>
                        </Col>
                    );
                })}
                {/* <div className="text-center">
                    <Link to="#" className="text-danger">
                        <i className="mdi mdi-spin mdi-loading me-1"></i> Load more
                    </Link>
                </div> */}
                </Row>
            </Card.Body>
        </Card>
    );
 
  
   
    };
    
    
    export default AvisCour;

   



