export type TeamMemberCour = {
    avatar: string;
    name: string;
    designation: string;
};

export type ReminderCour = {
    variant: string;
    title: string;
    date: string;
    time: string;
};

export type CommentCour = {
    avatar: string;
    name: string;
    time: string;
    content: {
        message?: string;
        media?: string[];
    };
    replies?: Comment[];
};

export type PostCour = {
    avatar: string;
    name: string;
    time: string;
    content: {
        message?: string;
        media?: string[];
    };
    comments?: Comment[];
};
