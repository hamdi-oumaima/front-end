
import { Col, Row } from 'react-bootstrap';
import { usePageTitle } from '../../hooks';
import "../../assets/images/Html-Css.jpg";
import "./Cour.css";
import SingleCour from './SingleCour';
import AvisCour from './CourInformations/AvisCour';
import CardCour from './CourInformations/CardCour';

 
const CourIndex = () =>{


    
     
     usePageTitle({
         title: '',
         breadCrumbItems: [
             {
                 path: '/Cour',
                 label: 'Cour',
                 active: true,
             },
         ],
     });

    return (
        <>
    <div className="main-bar">
        <div className="container">
            <div className="lienCard row">
            <a className="ud-heading-sm" href="/courses/development/">Développement</a>
            <a className="ud-heading-sm" href="/courses/development/programming-languages/">Langages de programmation</a>
            <a className="ud-heading-sm" href="/topic/object-oriented-programming/">Programmation orientée objet</a>
            </div>
            <h3 className='CardTit'>Python pour la POO: Programmation Orientée<br/> Objet en Python </h3>
            <p>Apprenez des compétences en Programmation Orientée Objet pour Python<br/> en écrivant du code lisible, et modulaire!</p>
           
    <p>
            <strong className='chiffre'>4,5</strong>
            <i className="fas fa-star starsColor"></i>
            <i className="fas fa-star starsColor"></i> 
            <i className="fas fa-star starsColor"></i> 
            <i className="fas fa-star starsColor"></i> 
            <i className="fas fa-star starsColor"></i> 
            (76 notes) 14720 participants 
    </p>
            <p>Dernière mise à jour&nbsp;: 10/2022</p>
                  
            </div>
      

    </div>
 
    <Row>
    <Col sm={2}></Col>
            <Col sm={5}>
                <AvisCour></AvisCour>
            </Col>
            <Col xl={5} >
                <CardCour></CardCour>
            </Col>
       
        </Row>
 
 
   </>
    );
   
    };
    
    
    export default CourIndex;

   



