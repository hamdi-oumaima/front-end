// types
import { GalleryItemCertification } from './types';

const gallery: GalleryItemCertification[] = [
    {
        id: 1,
        image: {
            src: 'https://3.bp.blogspot.com/-sFU98IcZzm8/Wv_hTJF3uRI/AAAAAAAADUU/6X6wOzH1r7IKGWHKISylbUZCBDTef4cSACLcBGAs/s1600/713270-1522689943.jpg',
            caption: 'Screenshot-1',
        },
        title: 'Nature Image',
        category: ['natural', 'personal'],
    },
    {
        id: 2,
        image: {
            src: 'https://3.bp.blogspot.com/-sFU98IcZzm8/Wv_hTJF3uRI/AAAAAAAADUU/6X6wOzH1r7IKGWHKISylbUZCBDTef4cSACLcBGAs/s1600/713270-1522689943.jpg',
            caption: 'Screenshot-2',
        },
        title: 'Gallary Image',
        category: ['creative', 'personal', 'photography'],
    },
    {
        id: 3,
        image: {
            src: 'https://3.bp.blogspot.com/-sFU98IcZzm8/Wv_hTJF3uRI/AAAAAAAADUU/6X6wOzH1r7IKGWHKISylbUZCBDTef4cSACLcBGAs/s1600/713270-1522689943.jpg',
            caption: 'Screenshot-3',
        },
        title: 'Gallary Image',
        category: ['natural', 'creative'],
    },
    {
        id: 4,
        image: {
            src: 'https://2.bp.blogspot.com/-v0lAZpDUaz4/Wv_hWICIdfI/AAAAAAAADUc/xewuzUGQEzo4s8psoMOE2CrJRB7-nVQAQCLcBGAs/s1600/Diploma%2Bin%2BCivil%2BEngineering.jpg',
            caption: 'Screenshot-4',
        },
        title: 'Gallary Image',
        category: ['personal', 'photography'],
    },
    {
        id: 5,
        image: {
            src: 'https://2.bp.blogspot.com/-v0lAZpDUaz4/Wv_hWICIdfI/AAAAAAAADUc/xewuzUGQEzo4s8psoMOE2CrJRB7-nVQAQCLcBGAs/s1600/Diploma%2Bin%2BCivil%2BEngineering.jpg',
            caption: 'Screenshot-5',
        },
        title: 'Gallary Image',
        category: ['creative', 'photography'],
    },
    {
        id: 6,
        image: {
            src: 'https://2.bp.blogspot.com/-v0lAZpDUaz4/Wv_hWICIdfI/AAAAAAAADUc/xewuzUGQEzo4s8psoMOE2CrJRB7-nVQAQCLcBGAs/s1600/Diploma%2Bin%2BCivil%2BEngineering.jpg',

            caption: 'Screenshot-6',
        },
        title: 'Gallary Image',
        category: ['natural', 'photography'],
    },
    {
        id: 7,
        image: {
            src: 'https://2.bp.blogspot.com/-XU9BposaMj8/Wv_ha1pgEZI/AAAAAAAADUo/4e2Gh9Go0ps_dcXHUQoyZFgVXIsBuVYnwCLcBGAs/s1600/SSC.jpg',
            caption: 'Screenshot-7',
        },
        title: 'Gallary Image',
        category: ['personal', 'photography', 'creative'],
    },
    {
        id: 8,
        image: {
            src: 'https://2.bp.blogspot.com/-XU9BposaMj8/Wv_ha1pgEZI/AAAAAAAADUo/4e2Gh9Go0ps_dcXHUQoyZFgVXIsBuVYnwCLcBGAs/s1600/SSC.jpg',
            caption: 'Screenshot-8',
        },
        title: 'Gallary Image',
        category: ['creative', 'photography', 'natural'],
    },
    {
        id: 9,
        image: {
            src: 'https://2.bp.blogspot.com/-XU9BposaMj8/Wv_ha1pgEZI/AAAAAAAADUo/4e2Gh9Go0ps_dcXHUQoyZFgVXIsBuVYnwCLcBGAs/s1600/SSC.jpg',
            caption: 'Screenshot-9',
        },
        title: 'Gallary Image',
        category: ['natural', 'personal'],
    },
    {
        id: 10,
        image: {
            src: 'https://2.bp.blogspot.com/-v0lAZpDUaz4/Wv_hWICIdfI/AAAAAAAADUc/xewuzUGQEzo4s8psoMOE2CrJRB7-nVQAQCLcBGAs/s1600/Diploma%2Bin%2BCivil%2BEngineering.jpg',
            caption: 'Screenshot-10',
        },
        title: 'Gallary Image',
        category: ['photography', 'creative'],
    },
    {
        id: 11,
        image: {
            src: 'https://2.bp.blogspot.com/-v0lAZpDUaz4/Wv_hWICIdfI/AAAAAAAADUc/xewuzUGQEzo4s8psoMOE2CrJRB7-nVQAQCLcBGAs/s1600/Diploma%2Bin%2BCivil%2BEngineering.jpg',

            caption: 'Screenshot-11',
        },
        title: 'Gallary Image',
        category: ['creative', 'photography'],
    },
    {
        id: 12,
        image: {
            src: 'https://2.bp.blogspot.com/-v0lAZpDUaz4/Wv_hWICIdfI/AAAAAAAADUc/xewuzUGQEzo4s8psoMOE2CrJRB7-nVQAQCLcBGAs/s1600/Diploma%2Bin%2BCivil%2BEngineering.jpg',

            caption: 'Screenshot-12',
        },
        title: 'Gallary Image',
        category: ['natural', 'creative', 'personal'],
    },
];

export { gallery };
