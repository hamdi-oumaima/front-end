export type ImageCertification = {
    src: string;
    caption: string;
};

export type GalleryItemCertification = {
    id?: number;
    image: ImageCertification;
    title?: string;
    userName?: string;
    avatar?: string;
    isLiked?: boolean;
    category?: string[];
};
