import React from 'react';
import { Collapse } from 'react-bootstrap';
import classNames from 'classnames';

// helpers
import { getHorizontalMenuItems } from '../../helpers/menu';

// components
import AppMenu from './Menu';
import { useRedux } from '../../hooks';

type NavbarProps = {
    isMenuOpened?: boolean;
};

const Navbar = ({ isMenuOpened }: NavbarProps) => {
    const { appSelector } = useRedux();

    const { userLoggedIn } = appSelector((state) => ({
        userLoggedIn: state.Auth.userLoggedIn,
    }));

    return (
        <div className="topnav">
            <div className="container-fluid">
                <nav className={classNames('navbar', 'navbar-expand-lg', 'topnav-menu', 'navbar-light')}>
                    <Collapse in={isMenuOpened} className="navbar-collapse">
                        <div id="topnav-menu-content">
                            <AppMenu menuItems={getHorizontalMenuItems(userLoggedIn)} />
                        </div>
                    </Collapse>
                </nav>
            </div>
        </div>
    );
};

export default Navbar;
