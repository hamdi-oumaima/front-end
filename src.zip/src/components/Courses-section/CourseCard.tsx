import React from 'react';
import './courses.scss';

export type CourseCardProps = {
    id?: number;
    image: string;
    title: string;
    title2?: string;
    description: string;
};

const CourseCard = (props: CourseCardProps) => {
    return (
        <div className="card-home">
            <span className="close"></span>
            <span className="arrow"></span>
            <article>
                <h2> {props.title} </h2>
                <div className="title">{props.title2}</div>
                <div className="pic">
                    <img src={props.image} alt="" />
                </div>

                <div className="desc">{props.description}</div>
            </article>
        </div>
    );
};

export default CourseCard;
