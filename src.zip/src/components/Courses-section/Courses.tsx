import React, { useState } from 'react';
import { Container, Row, Col } from 'reactstrap';
import Masonry, { ResponsiveMasonry } from 'react-responsive-masonry';
import CourseCard, { CourseCardProps } from './CourseCard';

import image1 from '../../assets/images/web-design copy.png';
import image2 from '../../assets/images/graphics-design copy.png';
import image3 from '../../assets/images/ui-ux copy.png';

const Courses = () => {
    const listCourse: CourseCardProps[] = [
        {
            id: 0,
            title: 'Elijah Green',
            title2: 'Bug Collector',
            image: image1,
            description:
                'Elijah has collected bugs since they were six years old and now has many dozen bugs but none in their pants',
        },
        {
            id: 1,
            title: 'Morgan Sweeney',
            title2: 'Ant Collector',
            image: image2,
            description:
                'Morgan has collected ants since they were six years old and now has many dozen ants but none in their pants.',
        },
        {
            id: 2,
            title: 'Adrian Woodward',
            title2: 'Fly Collector',
            image: image3,
            description:
                'Adrian has collected flies since they were six years old and now has many dozen flies but none in their pants.',
        },
    ];
    return (
        <>
            <Container className="mb-5 mt-5">
                <Row className="portfolioContainer">
                    <ResponsiveMasonry columnsCountBreakPoints={{ 350: 1, 750: 2, 900: 3 }}>
                        <Masonry gutter="3rem">
                            {(listCourse || []).map((item, index) => {
                                return (
                                    <div style={{ display: 'flex', width: '100%', justifyContent: 'center' }}>
                                        <CourseCard
                                            title={item.title}
                                            title2={item.title2}
                                            image={item.image}
                                            description={item.description}
                                            key={item.id}></CourseCard>
                                    </div>
                                );
                            })}
                        </Masonry>
                    </ResponsiveMasonry>
                </Row>
            </Container>
        </>
    );
};

export default Courses;
