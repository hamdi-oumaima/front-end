import React, { useState } from 'react';
import { Container, Row, Col } from 'reactstrap';

import chooseImg from '../../assets/images/why-choose-us copy.png';
import './choose-us.css';

const ChooseUs = () => {
    const [showVideo, setShowVideo] = useState(false);
    return (
        <section>
            <Container>
                <Row>
                    <Col lg="6" md="6">
                        <div className="choose__content">
                            <h2>Pourquoi nous choisir</h2>
                            <p className="chousePara">
                                Depuis plus de 7 ans, Tri Training accompagne ses partenaires pour prendre en charge
                                tous leurs besoins : rédaction de contenu, référencement, gestion d’identité visuelle,
                                développement web, Community management… Nous vous assurons une capacité de production
                                flexible vers la hausse ou la baisse au besoin.
                                {/* Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                Incidunt mollitia nostrum harum eos praesentium odit a sed quod
                aut fugit. Lorem ipsum dolor sit amet consectetur adipisicing
                elit. Reprehenderit omnis, culpa eligendi inventore perspiciatis
                minus. Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Dolores cupiditate facilis provident quidem accusamus impedit
                tenetur laboriosam debitis nisi eius! */}
                            </p>
                        </div>
                    </Col>

                    <Col lg="6" md="6">
                        <div className="choose__img">
                            {showVideo ? (
                                <div> </div>
                            ) : (
                                // <ReactPlayer
                                //   url="https://www.youtube.com/watch?v=qFp27TR4Yew"
                                //   controls
                                //   width="100%"
                                //   height="350px"
                                // />
                                <img src={chooseImg} alt="" className="w-100" />
                            )}

                            {!showVideo && (
                                <span className="play__icon">
                                    <i className="ri-play-circle-line" onClick={() => setShowVideo(!showVideo)}></i>
                                </span>
                            )}
                        </div>
                    </Col>
                </Row>
            </Container>
        </section>
    );
};

export default ChooseUs;
