import React from "react";
import { Container, Row, Col } from "reactstrap";

const Company = () => {
  return (
    <section>
      <Container>
       
        <Row>
       
          <Col lg="2" md="3" sm="4" xs="6">
            <h3 className="company  d-flex align-items-center gap-1">
              <i className="ti-vimeo"></i> Vimeo
            </h3>
          </Col>

          <Col lg="2" md="3" sm="4" xs="6">
            <h3 className="company d-flex align-items-center gap-1">
              <i className="ti-pinterest"></i> Pinterest
            </h3>
          </Col>

          <Col lg="2" md="3" sm="4" xs="6">
            <h3 className="company d-flex align-items-center gap-1">
              <i className="ti-dribbble"></i> Dribble
            </h3>
          </Col>

          <Col lg="2" md="3" sm="4" xs="6">
            <h3 className="company d-flex align-items-center gap-1">
              {" "}
              <i className="ti-apple"></i> Apple
            </h3>
          </Col>

          {/* <Col lg="2" md="3" sm="4" xs="6">
            <h3 className=" d-flex align-items-center gap-1">
              {" "}
              <i className="ri-finder"></i> Finder
            </h3>
          </Col> */}

          <Col lg="2" md="3" sm="4" xs="6">
            <h2 className="company d-flex align-items-center gap-1">
              {" "}
              <i className="ti-google"></i> Google
              {/* <i class="ri-google-fill"></i> Google*/}
            </h2> 
          </Col>
        
        </Row>
       
      </Container>
    </section>
  );
};

export default Company;
