import React from 'react';
import { Container, Row, Col, ListGroup, ListGroupItem } from 'reactstrap';
import logoLight from '../../assets/images/Logo-Final-tritraining.png';
import './footer.css';
import classNames from 'classnames';

const footerQuickLinks = [
    {
        display: 'Home',
        url: '#',
    },
    {
        display: 'About US',
        url: '#',
    },

    {
        display: 'Courses',
        url: '#',
    },

    {
        display: 'Blog',
        url: '#',
    },
];

const footerInfoLinks = [
    {
        display: 'Privacy Policy',
        url: '#',
    },
    {
        display: 'Membership',
        url: '#',
    },

    {
        display: 'Purchases Guide',
        url: '#',
    },

    {
        display: 'Terms of Service',
        url: '#',
    },
];

const FooterPublic = () => {
    return (
        <footer className="footer">
            <div className="footer-left col-md-4 col-sm-6">
                <p className="about">
                    <span> About the company</span> Ut congue augue non tellus bibendum, in varius tellus condimentum.
                    In scelerisque nibh tortor, sed rhoncus odio condimentum in. Sed sed est ut sapien ultrices
                    eleifend. Integer tellus est, vehicula eu lectus tincidunt, ultricies feugiat leo. Suspendisse
                    tellus elit, pharetra in hendrerit ut, aliquam quis augue. Nam ut nibh mollis, tristique ante sed,
                    viverra massa.
                </p>
                <div className="icons">
                    <a href="#">
                        <i className={classNames('fab', 'fa-' + 'far fa-facebook')}></i>
                    </a>
                    <a href="#">
                        <i className="fab fa-far fa-twitter"></i>
                    </a>
                    <a href="#">
                        <i className="fab fa-far fa-linkedin"></i>
                    </a>
                    <a href="#">
                        <i className="fab fa-far fa-google-plus"></i>
                    </a>
                    <a href="#">
                        <i className="fab fa-far fa-instagram"></i>
                    </a>
                </div>
            </div>
            <div className="footer-center col-md-4 col-sm-6">
                <div>
                    <i className="fa fa-map-marker"></i>
                    <p>
                        <span> Street name and number</span> City, Country
                    </p>
                </div>
                <div>
                    <i className="fa fa-phone"></i>
                    <p> (+00) 0000 000 000</p>
                </div>
                <div>
                    <i className="fa fa-envelope"></i>
                    <p>
                        <a href="#"> office@company.com</a>
                    </p>
                </div>
            </div>
            <div className="footer-right col-md-4 col-sm-6">
                <h2>
                    <img src={logoLight} alt="" style={{ width: '250px' }} />
                </h2>
                <p className="menu">
                    <a href="#"> Home</a> |<a href="#"> About</a> |<a href="#"> Services</a> |<a href="#"> Portfolio</a>{' '}
                    |<a href="#"> News</a> |<a href="#"> Contact</a>
                </p>
                <p className="name"> TriWeb&copy; 2023</p>
            </div>
        </footer>
    );
};

export default FooterPublic;
